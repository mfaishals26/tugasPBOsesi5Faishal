/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author komputer jarkom 4
 */
public class Kendaraan {
    String namapemilik; 
    String nomorplat; 
    String jeniskendaraan; 
    
  
    
    public void tampilkaninfo(String namapemilik,String nomorplat,String jeniskendaraan){
        this.namapemilik = namapemilik;
        this.nomorplat = nomorplat;
        this.jeniskendaraan = jeniskendaraan;
        
    }

    public String getNamapemilik() {
        return namapemilik;
    }

    public String getNomorplat() {
        return nomorplat;
    }

    public String getJeniskendaraan() {
        return jeniskendaraan;
    }
    
   public void servicekendaraan(){
       System.out.println("Service sedang dilakukan");
          
   }
    public void servicekendaraan(String jenisservice){
       System.out.println("Service jenis" + jenisservice + "sedang dilakukan");
          
   }
    
}
