/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author komputer jarkom 4
 */
public class Mobil extends Kendaraan {
    int jumlahpintu;
    boolean status=false;
    
     public Mobil(int jumlahpintu){
        super.namapemilik = "Andi";
        this.nomorplat = "B1234XYZ";
        this.jeniskendaraan = "Mobil";
        this.jumlahpintu = 4;
        
    }

   
    public void tampilkaninfo(){
        System.out.println("== info kendaraan ==");
        System.out.println("Nama Pemilik  :" + super.namapemilik);
        System.out.println("Nomor Plat  :" + this.nomorplat);
        System.out.println("Jenis kendaraan :" + this.jeniskendaraan);
        System.out.println("Jumlah pintu :" + getJumlahpintu());
        
        System.out.println("==============");
    
    }

    public int getJumlahpintu() {
        return jumlahpintu;
    }

    public void setJumlahpintu(int jumlahpintu) {
        this.jumlahpintu = jumlahpintu;
    }
    
    
}

