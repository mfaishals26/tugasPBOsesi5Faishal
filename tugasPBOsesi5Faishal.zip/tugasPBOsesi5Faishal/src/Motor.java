/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author komputer jarkom 4
 */
public class Motor extends Kendaraan {
     String jumlahpintu;
     Boolean memilikibox;

       public Motor(Boolean memilikibox){
        super.namapemilik = "Budi";
        this.nomorplat = "D5678ABC";
        this.jeniskendaraan = "Motor";
        this.memilikibox = true;
        
    }

     
    public Boolean getmemilikibox() {
        return memilikibox;
    }
             
    
    public void tampilkaninfo(){
        System.out.println("Nama Pemilik  :" + this.namapemilik);
        System.out.println("Nomor Plat  :" + this.nomorplat);
        System.out.println("Jenis kendaraan :" + this.jeniskendaraan);
        System.out.println("Memilikibox :" + (this.memilikibox ? "ya" : "tidak"));
    
    }

    public void setMemilikibox(Boolean memilikibox) {
        this.memilikibox = memilikibox;
    }
    
    
  
   

  

}
