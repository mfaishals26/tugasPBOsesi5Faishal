/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author komputer jarkom 4
 */
public class main {
     public static void main(String[]args){
        Mobil Mobil = new Mobil(4);
        Motor Motor = new Motor(true );
        
        Mobil.tampilkaninfo();
        Motor.tampilkaninfo();
        
     
       System.out.println("Service sedang dilakukan");
    
       
     
       Motor.servicekendaraan("  tune up  ");
          
     
    }
     
     
}
